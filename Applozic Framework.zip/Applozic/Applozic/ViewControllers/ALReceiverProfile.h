//
//  ALReceiverProfile.h
//  Applozic
//
//  Created by Abhishek Thapliyal on 3/30/17.
//  Copyright © 2017 applozic Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ALContactService.h"

@interface ALReceiverProfile : UIViewController

@property (strong, nonatomic) ALContact *alContact;

@end
