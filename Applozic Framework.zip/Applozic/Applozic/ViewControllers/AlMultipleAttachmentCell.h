//
//  AlMultipleAttachmentCell.h
//  Applozic
//
//  Created by devashish on 29/03/2016.
//  Copyright © 2016 applozic Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlMultipleAttachmentCell : UICollectionViewCell


@property (weak, nonatomic) IBOutlet UIImageView *imageView;


@end
