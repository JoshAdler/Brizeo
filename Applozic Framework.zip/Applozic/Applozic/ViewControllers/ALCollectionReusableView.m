//
//  ALCollectionReusableView.m
//  Applozic
//
//  Created by devashish on 18/04/2016.
//  Copyright © 2016 applozic Inc. All rights reserved.
//

#import "ALCollectionReusableView.h"

@implementation ALCollectionReusableView

@end
