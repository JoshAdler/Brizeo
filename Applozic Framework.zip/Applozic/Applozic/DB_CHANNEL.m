//
//  DB_CHANNEL.m
//  Applozic
//
//  Created by devashish on 28/12/2015.
//  Copyright © 2015 applozic Inc. All rights reserved.
//

#import "DB_CHANNEL.h"

@implementation DB_CHANNEL

@dynamic adminId;
@dynamic channelDisplayName;
@dynamic channelKey;
@dynamic channelImageURL;
@dynamic clientChannelKey;
@dynamic type;
@dynamic userCount;
@dynamic unreadCount;
@dynamic isLeft;
@dynamic parentGroupKey;
@dynamic parentClientGroupKey;
@dynamic notificationAfterTime;
@dynamic deletedAtTime;
@dynamic metadata;

@end
