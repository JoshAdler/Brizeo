//
//  ALChannelInfo.m
//  Applozic
//
//  Created by devashish on 28/12/2015.
//  Copyright © 2015 applozic Inc. All rights reserved.
//

#import "ALChannelInfo.h"

@implementation ALChannelInfo

@end
