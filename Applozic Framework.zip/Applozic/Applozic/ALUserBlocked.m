//
//  ALUserBlocked.m
//  Applozic
//
//  Created by devashish on 10/03/2016.
//  Copyright © 2016 applozic Inc. All rights reserved.
//

#import "ALUserBlocked.h"

@implementation ALUserBlocked

@end
