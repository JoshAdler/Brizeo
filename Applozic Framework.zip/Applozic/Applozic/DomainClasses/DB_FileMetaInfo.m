//
//  DB_FileMetaInfo.m
//  ChatApp
//
//  Created by shaik riyaz on 23/08/15.
//  Copyright (c) 2015 AppLogic. All rights reserved.
//

#import "DB_FileMetaInfo.h"


@implementation DB_FileMetaInfo

@dynamic blobKeyString;
@dynamic contentType;
@dynamic createdAtTime;
@dynamic key;
@dynamic name;
@dynamic size;
@dynamic suUserKeyString;
@dynamic thumbnailUrl;

@end
