//
//  ALChannelInfo.h
//  Applozic
//
//  Created by devashish on 28/12/2015.
//  Copyright © 2015 applozic Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ALChannelInfo : NSObject

@property (nonatomic, strong) NSString *groupName;
@property (nonatomic, strong) NSMutableArray *members;

@end
