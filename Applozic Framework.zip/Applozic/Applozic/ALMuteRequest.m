//
//  ALMuteRequest.m
//  Applozic
//
//  Created by Adarsh Kumar Mishra on 1/12/17.
//  Copyright © 2017 applozic Inc. All rights reserved.
//

#import "ALMuteRequest.h"

@implementation ALMuteRequest

@end
