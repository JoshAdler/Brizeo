**To delete a base path mapping for a custom domain name in the specified region**

Command::

  aws apigateway delete-base-path-mapping --domain-name 'api.domain.tld' --base-path 'dev' --region us-west-2

